/*
Author:Melendrez, Jacob
Date: Nov 26 2020
Description:have a message board that has a register, login and logout function.
*/
import express from 'express';
import exphbs from "express-handlebars";
import bcrypt from 'bcrypt';
import sqlite3 from 'sqlite3';
import { open } from "sqlite";
import cookieParser from 'cookie-parser';
import { grantAccess, findUser } from './auth';

//creates the database with the tables
export const dbPromise = open({
    filename: "data.db",
    driver: sqlite3.Database,
})

const app = express();

app.engine("handlebars", exphbs());
app.set("view engine", "handlebars");

app.use(cookieParser());
app.use(express.urlencoded({ extended: false }));

//uses cookies to check if the user is logged in
app.use(async (req, res, next) =>{
    const { userToken } = req.cookies;
    if(!userToken) {return next();}
    try{
        const user = await findUser(userToken);
        req.user = user;
    } catch (e) { return next(e); }
    next()
})

//if the user is logged in, then user can't access the registeration form.
app.get('/register', (req, res) =>{
    if(req.user){ return res.redirect('/'); }
    res.render('register');
})

//if the user is logged in, then user can't access the log in form.
app.get('/login', (req, res) =>{
    if(req.user){ return res.redirect('/'); }
    res.render('login');
})

//logs out the user when they are logged in
app.get('/logout', (req, res) =>{
    res.clearCookie('userToken');
    res.redirect('/');
})

//retrieves movies from the database.
app.get("/", async (req, res) =>{
    const db = await dbPromise;
    const movies = await db.all(
        `SELECT
        Movies.id,
        Movies.movieTitle,
        Movies.movieLength,
        Movies.movieRating
        FROM Movies`
    );
    res.render("home", {movies, user: req.user});
});

//allows the user to insert there info, hash their password and allows them to login
app.post('/register', async (req, res) =>{
    const db = await dbPromise;
    const {
        username,
        email,
        password,
        password2
    } = req.body;
    if(password===password2)
    {
        // takes the password and hash it.
        const passwordHash = await bcrypt.hash(password, 10);

        try{
            //insert users info into database
            await db.run('INSERT INTO Users (username, email, password) VALUES (?, ?, ?);',
                username,
                email,
                passwordHash
            );
            //keeps track of what user is registered in using cookies. also grants access to new user.
            const user = await db.get('SELECT id FROM Users WHERE email=?', email);
            const token = await grantAccess(user.id);
            res.cookie('userToken', token);
            res.redirect('/');
        }
        catch (e) { return res.render('register', {error: e}); }//if something goes wrong during registration, error is passed.
    }
    else {res.render('register', {error: 'password do not match'})}
})

//logs in user using email and password.
app.post('/login', async (req, res) =>{
    const db = await dbPromise;
    const {
        email,
        password
    } = req.body;

    try{
        //checks users email if in the database
        const existingUser = await db.get('SELECT * FROM Users WHERE email=?', email);
        if(!existingUser) { throw 'incorrect login'; }

        //checks users password by decrpting hash from database
        const passwordMatch = await bcrypt.compare(password, existingUser.password);
        if(!passwordMatch) { throw 'incorrect login'; }

        //if user has correct email and password it is grant access through grantAccess function in auth.js
        const token = await grantAccess(existingUser.id);
        res.cookie('userToken', token);
        res.redirect('/');
    } catch (e) { return res.render('login', { error: e }); }
})

//allows user to post movies if they are logged in.
app.post('/movies', async (req, res) =>{
    const db = await dbPromise;
    try{
        //insert movies into the movies table in database.
        await db.run('INSERT INTO Movies (movieTitle, movieLength, movieRating) VALUES (?, ?, ?);', req.body.movieTitle, req.body.movieLength, req.body.movieRating);
        res.redirect('/');
    }
    catch (e) {return res.render('home', {error: e, user: req.user}); }
})

//reads databases and set the url to localhost:8080
const setup = async () => {
    const db = await dbPromise;
    await db.migrate();

    app.listen(8080, () =>{
        console.log("listening on http://localhost:8080");
    });
}

setup();//calls setup function