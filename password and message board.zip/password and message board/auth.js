/*
Author:Melendrez, Jacob
Date: Nov 26 2020
Description:have a message board that has a register, login and logout function.
*/
import { v4 as uuidv4 } from 'uuid';
import { dbPromise } from './index';

//checks the register info and verfies that a same user can't identify twice.
export const grantAccess = async (userId) =>{
    const db = await dbPromise;
    const tokenString = uuidv4();
    //inserts data to authors table in database so cookie can be made to keep track of user in index.js.
    await db.run('INSERT INTO AuthTokens (token, userId) VALUES (?, ?);',
        tokenString,
        userId
    );
    return tokenString;
}

//finds user in database to allow log in.
export const findUser = async (userToken) =>{
    const db = await dbPromise;
    //find user in table database
    const token = await db.get('SELECT * FROM AuthTokens WHERE token=?;', userToken);
    
    //can't find user return null for no user found.
    if(!token){ return null; }

    //returns users id, email and username from table database if user is registered.
    const user = await db.get('SELECT id, email, username FROM Users WHERE id=?;', token.userId);

    return user;
}